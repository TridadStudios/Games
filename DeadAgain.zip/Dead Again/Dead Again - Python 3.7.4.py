import time
import random
import pickle

x = 5
y = 1
money = 20
hp = 20
maxhp = 20
action = 0
weapon = 0 #shows no. (weapon) of [weapons] in hotbar
weapons = ["n/a", "Longsword", "Spear", "Bronze Scimitar", "Sword of the Somber Burden", "Eos Battleaxe", "Sword of the Solemn Pain"]
inv = ["Old Pendant"]
potions = []
attack = 0
rand = 0
flee = 0
enemy = 0
enemies = ["", "Undead Bandit", "Pale Lady", "Serpent-Fish", "Castille Sentry", "Undead Swordsman", "Bearer of a Torch", "Priest of the Somber Burden", "Catacomb Great Rat", "Undead Spelunker", "Undead Knight of Eos", "Eyeless Beast", "Undead Necromancer", "Flaming Reaper's Wheel", "Undead Reaper"]
bosses = ["", "He of the Solemn Pain", "The Serpent-Shark", "Sentinel Ashara", "Lord Arthan the Undead", "???", "Royal Sorcerer Navarel", "Themis, Undead Queen"]
boss1 = 1
boss2 = 1
boss3 = 1
boss4 = 1
boss5 = 1
boss6 = 1
eHP = 0
eATTACK = 0
q = 0
w = 0
e = 0
mo = 1
mm = 1
water = 6
key = 0
key1 = 0
key2 = 0
key3 = 0
key4 = 0
keys = 0
checkpoint = 0

def battle(param1, param2, health): ###########################################
        global hp
        global maxhp
        global y
        global money
        global checkpoint
        enemy = random.randint(param1, param2)
        if enemy == 1: #Undead Bandit
            eHP = 10
            eATTACK = 2
        if enemy == 2: #Pale Lady
            eHP = 15
            eATTACK = 4
        if enemy == 3: #Serpent-Fish
            eHP = 11
            eATTACK = 3
        if enemy == 4: #Castille Sentry
            eHP = 18
            eATTACK = 3
        if enemy == 5: #Undead Swordsman
            eHP = 15
            eATTACK = 5
        if enemy == 6: #Bearer of a Torch
            eHP = 11
            eATTACK = 8
        if enemy == 7: #Priest of the Somber Burden
            eHP = 20
            eATTACK = 4
        if enemy == 8: #Catacomb Great Rat
            eHP = 20
            eATTACK = 5
        if enemy == 9: #Undead Spelunker
            eHP = 20
            eATTACK = 7
        if enemy == 10: #Undead Knight of Eos
            eHP = 40
            eATTACK = 8
        if enemy == 11: #Eyeless Beast
            eHP = 30
            eATTACK = 8
        if enemy == 12: #Undead Necromancer
            eHP = 16
            eATTACK = 16
        if enemy == 13: #Flaming Reaper's Wheel
            eHP = 35
            eATTACK = 10
        if enemy == 14: #Undead Reaper
            eHP = 50
            eATTACK = 10
        print("While walking, you're ambushed by a " + enemies[enemy] + "!")
        while 1:
            if eHP > 0:
                input()
            print()
            print()
            print()
            if health < 1:
                print("You've died...")
                time.sleep(1)
                print("Sliding down the endless spiral...")
                time.sleep(1)
                print("Into the abyss...")
                time.sleep(1)
                print(".....")
                time.sleep(1)
                print("But enough of this.")
                time.sleep(1)
                print("Awaken now, where you began...")
                if checkpoint == 0:
                    x = 5
                    y = 1
                elif checkpoint == 1:
                    x = 6
                    y = 7
                elif checkpoint == 2:
                    x = 5
                    y = 16
                break
            if eHP < 1:
                print("Congratulations, you killed the " + enemies[enemy] + "!")
                if y <= 6:
                    e = random.randint(2, 6)
                else:
                    e = random.randint(4, 8)
                print("You gained " + str(e) + "g!")
                money+=e
                print()
                break
            print("----------------")
            print("Your HP: " + str(health) + "/" + str(maxhp))
            print("----------------")
            print(enemies[enemy] + " HP: " + str(eHP))
            print("----------------")
            print("What will you do?")
            print("a/1: Attack with " + weapons[weapon] + " (AP:" + str(attack) + ")")
            if "HP Potion" in inv:
                print("h/2: Heal (" + str(len(potions)) + ")")
            print("f/3: Flee (50% chance)")
            action = input(">>> ")
            print()
            if action == "a" or action == "1":
                  q = attack + random.randint(-1, 1)
                  print("You do " + str(q) + " damage to the " + enemies[enemy] + "!")
                  eHP-=q
            if (action == "h" or action == "2") and "HP Potion" in inv:
                if "Life Patch" in inv:
                    health+=20
                    print("Healed 20HP")
                else:
                    health+=15
                    print("Healed 15HP")
                inv.remove("HP Potion")
                potions.remove("x")
                if health > maxhp:
                    health = maxhp
            if action == "f" or action == "3":
                  flee = random.randint(1, 100)
                  if flee <= 50:
                      print("You escaped!")
                      break
                      hp = maxhp
                  else:
                      print("You couldn't escape!")
            w = eATTACK + random.randint(-1, 1)
            input()
            if eHP > 0:
                print("The " + enemies[enemy] + " deals " + str(w) + " damage to you!")
                health-=w
                hp = health

def bossfight(opp, health, hol = 30): #############################################
        global hp
        global maxhp
        global money
        global boss1
        global boss2
        global boss3
        global boss4
        global boss5
        global boss6
        global water
        global checkpoint
        global x
        global y
        enemy = bosses[opp]
        if enemy == "He of the Solemn Pain": #He of the Solemn Pain
            hol = 30
            eATTACK = 6
        if enemy == "The Serpent-Shark": #The Serpent-Shark
            hol = 60
            eATTACK = 7
        if enemy == "Sentinel Ashara": #Sentinel Ashara
            hol = 45
            eATTACK = 6
        if enemy == "Lord Arthan the Undead": #Lord Arthan the Undead
            hol = 65
            eATTACK = 8
        if enemy == "???": #???
            hol = 45
            eATTACK = 8
        if enemy == "Royal Sorcerer Navarel": #Royal Sorcerer Navarel
            hol = 100
            eATTACK = 10
        if enemy == "Themis, Undead Queen": #Themis, Undead Queen
            hol = 160
            eATTACK = 10
        print(bosses[opp] + " approaches. Brace yourself...")
        while 1:
            if eHP > 0:
                input()
            print()
            print()
            print()
            if health < 1:
                print("You've died...")
                time.sleep(1)
                print("Sliding down the endless spiral...")
                time.sleep(1)
                print("Into the abyss...")
                time.sleep(1)
                print(".....")
                time.sleep(1)
                print("But enough of this.")
                time.sleep(1)
                print("Awaken now, where you began...")
                if checkpoint == 0:
                    x = 5
                    y = 1
                elif checkpoint == 1:
                    x = 6
                    y = 7
                elif checkpoint == 2:
                    x = 5
                    y = 16
                break
            if hol < 1:
                print("Congratulations, " + bosses[opp] + " was slain...")
                e = random.randint(6, 12)
                print("You gained " + str(e) + "g!")
                money+=e
                print()
                if bosses[opp] == "He of the Solemn Pain": #
                    print("You are about to take the warrior's sword, but unfortunately, it falls \n\
into the chasm. Who knows, maybe later you will be able to retrieve it.")
                    boss1 = 0
                if bosses[opp] == "The Serpent-Shark": #
                    print("YThe great creature returns back into the water, defeated.\n\
But not killed.\n\
\n\
You should probably leave.")
                    water = 6
                if bosses[opp] == "Sentinel Ashara": #
                    print("Having defeaten the sentry, you decide to take her scitmitar.")
                    boss2 = 0
                    inv.append("Bronze Scimitar")
                if bosses[opp] == "Lord Arthan the Undead": #
                    print("As you strike the finishing blow, Arthan and his staff dissintegrate with\n\
a horrifying scream.")
                    boss3 = 0
                if bosses[opp] == "???": #
                    print("Striking at the strange thing one more time, your weapon hits nothing.\n\
Whatever it was, it's either gone or dead now...")
                    boss4 = 0
                if bosses[opp] == "Royal Sorcerer Navarel": #
                    print("After the long fight, you hit Navaler one last time, finishing off the\n\
old, undead necromancer.")
                    boss5 = 0
                if bosses[opp] == "Themis, Undead Queen": #
                    print("The queen starts to crumble. 'Thank you', she says in a normal human voice.\n\
Along with her, the other undead start to crumble, as do you.")
                    print()
                    print("You feel content. You managed to stop the Undead Scourge.")
                    print("Having overcome the hardships, you may finally die in peace.")
                    boss6 = 0
                break
            if bosses[opp] == "Themis, Undead Queen": #
                print("‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡")
                print("Your HP: " + str(health) + "/" + str(maxhp))
                print("‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡")
                print(bosses[opp] + " HP: " + str(hol))
                print("‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡")
                print("What will you do?")
                print("a/1: Attack with " + weapons[weapon] + " (AP:" + str(attack) + ")")
            else:
                print("<><><><><><><><>")
                print("Your HP: " + str(health) + "/" + str(maxhp))
                print("<><><><><><><><>")
                print(bosses[opp] + " HP: " + str(hol))
                print("<><><><><><><><>")
                print("What will you do?")
                print("a/1: Attack with " + weapons[weapon] + " (AP:" + str(attack) + ")")
            if "HP Potion" in inv:
                print("h/2: Heal (" + str(len(potions)) + ")")
            action = input(">>> ")
            if action == "a" or action == "1":
                  q = attack + random.randint(-1, 1)
                  print("You do " + str(q) + " damage to the " + bosses[opp] + "!")
                  hol-=q
            if (action == "h" or action == "2") and "HP Potion" in inv:
                if "Life Patch" in inv:
                    print("Healed 20HP")
                    health+=20
                else:
                    print("Healed 15HP")
                    health+=15
                inv.remove("HP Potion")
                potions.remove("x")
                if health > maxhp:
                    health = maxhp
            w = eATTACK + random.randint(-1, 1)
            input()
            if hol > 0:
                print(bosses[opp] + " deals " + str(w) + " damage to you!")
                health-=w
                hp = health
                      

print("                                ------------------")
print("                                |   Dead Again   |")
print("                                ------------------")
print("                             A text adventure game by")
print("                                  Tridad Studios")
print()
print()
print("                                         _")
print("                                        / \\")
print("                                       /   \\")
print("                                      /  |  \\")
print("                                      | -O- |")
print("                                      \\  |  /")
print("                                       \\   /")
print("                                        \\_/")
print()
print()
input("                                   PRESS--ENTER")
print("\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
")

while 1:
    print("\n\
\n\
\n\
\n\
\n\
")
    if hp > maxhp:
        hp = maxhp
    if weapon == 0: #Bare Hands
        attack = 1
    if weapon == 1: #Longsword
        attack = 5
    if weapon == 2: #Spear
        attack = 6
    if weapon == 3: #Bronze Scimitar
        attack = 9
    if weapon == 4: #Sword of the Somber Burden
        attack = 11
    if weapon == 5: #Eos Battleaxe
        attack = 15
    if weapon == 6: #Sword of the Solemn Pain
        attack = 20
    print("----------------") #hotbar
    print("Health: " + str(hp) + "/" + str(maxhp)) 
    print("Money: " + str(money) + "g")
    print()
    print("Weapon: " + weapons[weapon])
    print("Attack Power: " + str(attack))
    print("----------------")
    print("Inventory(i): " + str(inv))
    print("----------------")
    if x == 5 and y == 1: #Location Names and co-ords
        print("???")
    if x == 5 and y == 2:
        print("Harelia Town")
    if x == 4 and y == 2:
        print("Harelia Town General Store")
    if x == 6 and y == 2:
        print("Triple-Pony Inn")
    if x >= 4 and x <= 7 and y >= 3 and y <= 6:
        print("Forest of Lost Souls")
    if x >= 1 and x <= 3 and y == 5:
        print("The Bridge of Eos")
    if x >= 8 and x <= 9 and y == 4:
        print("Blackwater Bay")
    if x >= 5 and x <= 7 and y >= 7 and y <= 11:
        print("Cantint Castille")
    if x >= 5 and x <= 7 and y >= 12 and y <= 15:
        print("The Black Chasm of Undead")
    if x >= 3 and x <= 5 and y >= 16 and y <= 17:
        print("Doorstep of Eos")
    if x >= 6 and x <= 8 and y >= 16 and y <= 20:
        print("Eos, the Sunken Kingdom")
    print("x:" + str(x) + " / y:" + str(y))
    print("----------------")
    
    if x == 5 and y == 1: #Harelia Well: game start
        print("You find yourself in a dark room, filled with water up to the ankles. The only \n\
exit appears to be a rickety-looking ladder. There appears to be a sword on \n\
the floor next to you.")
        print("----------------")
        print("w: head up the ladder")
        if weapon == 0:
            print("e: pick up sword")
        action = input(">>> ")
        print()
        if action == "e":
            weapon = 1
            inv.append("Longsword")
            print("You take the sword in your hand. It feels quite sturdy.")
        if action == "w":
            y+=1
            print("You head up the ladder, and pop out of a well in the middle of a small \n\
village. Though you scare some chickens, the villagers don't seem very perturbed\n\
by your presence.")
            
    elif x == 5 and y == 2: #Harelia Town
        print("Looking around, you see a few Harelians milling about. The small town \n\
only contains one proper shop, but there's an inn as well.")
        print("----------------")
        print("a: check out the shop")
        print("d: check out the inn")
        print("w: leave the village")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You enter the village's general store, where a grizzled old man sits \n\
a grizzled old man. 'Whaddya want?' he asks you gruffly.")
        if action == "d":
            x+=1
            print("You enter the village's inn, the Triple-Pony. It seems pretty empty, \n\
and the barkeep excitedly offers you a room.")
        if action == "w":
            y+=1
            print("You head out of the village, no one giving you a second thought.")

    elif x == 6 and y == 2: #The Triple-Pony Inn
        print("A nice day's rest could be good for your wounds.")
        print("----------------")
        print("r: rent a room")
        print("a: head back out")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You decide to not rent a room for now.")
        if action == "r":
            x-=1
            print("You rent a room and take a well-deserved rest. The next day, you head \n\
back out into the town")
            hp = maxhp
        elif action == "r" and money < 2:
            print("Unfortunately, you don't have the funds for that.")

    elif x == 4 and y == 2: #Harelia General Store
        print("The items on sale are: \n\
1. HP Potion (heals 15HP), for 5g")
        if not "Atlas" in inv:
            print("2. Atlas (contains coordinates to various locations), for 10g")
        print("----------------")
        print("d: leave shop")
        print("1: purchase an HP potion")
        if not "Atlas" in inv:
            print("2: purchase an atlas")
        action = input(">>> ")
        if action == "1": #HP Potion (buy)
            if money >= 5:
                money-=5
                print("'Here 'ya go.'")
                inv.append("HP Potion")
                potions.append("x")
            else:
                print("'What're you on about?', the shopkeep complains, 'Ye don' 'ave the cash!'")
        elif action == "2": #Atlas (buy)
            if not "Atlas" in inv:
                if money >= 10:
                    money-=10
                    print("'Here 'ya go.'")
                    inv.append("Atlas")
                    print("'By the way, I think I should mention', the shopkeeper whispers,\n\
'Don't go to Blackwater Bay. Just don't.'") 
                else:
                    print("'What're you on about?', the shopkeep complains, 'Ye don' 'ave the cash!'")
        elif action == "d":
            x+=1
            print("'Yeah, off wit' ya!, the shopkeep grumbles.'")

                #FOREST OF LOST SOULS
    elif x >= 4 and x <= 7 and y >= 3 and y <= 6 and not (x == 7 and y == 4): 
        rand = random.randint(1, 100)
        if rand >= 85:
            battle(1, 3, hp)
        if hp > 0:
            print("You find yourself in a strange forest. Every direction seems to lead to a \n\
similar place.")
        print("----------------")
        if y < 6 or x == 6:
            print("w: move north")
        if y > 3 or x == 5:
            print("s: move south")
        if x > 4 or y == 5:
            print("a: move west")
        if x < 7 or y == 4:
            print("d: move east")
        action = input(">>> ")
        if action == "w" and (y < 6 or x == 6):
            y = y + 1
            print("You continue through the forest.")
        elif action == "s" and (y > 3 or x == 5):
            y = y - 1
            print("You continue through the forest.")
        elif action == "d" and (x < 7 or y == 4):
            x = x + 1
            print("You continue through the forest.")
        elif action == "a" and (x > 4 or y == 5):
            x = x - 1
            print("You continue through the forest.")

    elif x == 3 and y == 5: #Bridge of Eos 1
        print("You find yourself on the edge of the Bridge of Eos. The long bridge \n\
only spans to about halfway across a massive chasm, however it is \n\
still very large.")
        print("----------------")
        print("a: cross the bridge")
        print("d: return to the forest")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You walk along the stone bridge.")
        if action == "d":
            x+=1
            print("You return to the forest.")

    elif x == 2 and y == 5: #Bridge of Eos 2
        if boss1 == 1:
            print("As you are walking along the bridge, you notice a human-like shape\n\
not very far away. Looking more closely, you notice that the man \n\
is staring straight at you, with his greatsword drawn, and resting \n\
his shoulder. He's not making any moves, though.")
        else:
            print("There's not much on the bridge here, really.")
        print("----------------")
        print("a: approach the bridge's edge")
        print("d: go back")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You proceed to the edge of the bridge...")
        if action == "d":
            x+=1
            print("You decide to go back.")

    elif x == 1 and y == 5: #He of the Solemn Pain
        if boss1 == 1:
            print("As you approach the man, he slowly paces towards you. His intentions\n\
do not seem friendly...")
            bossfight(1, hp)
        else:
            print("There's nothing here, not anymore. There's nothing to do but...")
        if hp > 0:
            print("----------------")
            print("d: turn back")
            action = input(">>> ")
            if action == "d":
                x+=1
                print("You decide to go back.")

    elif x == 7 and y == 4: #Blackwater Bay Entrance
        water = 6
        print("Walking along the strange forest road, you come across a narrow, winding\n\
path, leading to who knows where. Wherever it leads to, the salt-water smell\n\
suggests that it is somewhere by the sea.")
        print("----------------")
        if y < 6 or x == 6:
            print("w: move north")
        if y > 3 or x == 5:
            print("s: move south")
        if x > 4 or y == 5:
            print("a: move west")
        if x < 7 or y == 4:
            print("d: follow the path")
        action = input(">>> ")
        if action == "w" and (y < 6 or x == 6):
            y = y + 1
            print("You continue through the forest.")
        elif action == "s" and (y > 3 or x == 6):
            y = y - 1
            print("You continue through the forest.")
        elif action == "d" and (x < 7 or y == 4):
            x = x + 1
            print("You continue through the forest.")
        elif action == "a" and (x > 4 or y == 5):
            x = x - 1
            print("You continue through the forest.")

    elif x == 8 and y == 4: #Blackwater Bay 1
        print("You emerge from the forest, into what appears to be an abandoned\n\
fishing village. But there's inexplicably pitch-black water, churning\n\
and frothing, with a strange white, glowing spot...")
        print()
        if water >= 4:
            print("The water churns and froths...")
        if water >= 2 and water < 4:
            print("The waves grow ever larger...")
        if water == 1:
            print("The white glow shines with a newfound intensity...")
        print("----------------")
        print("a: leave the village")
        print("d: explore the village")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You decide to leave the strange place.")
        if action == "d":
            x+=1
            print("You explore the dilapidated village.")
        water-=1
    

    elif x == 9 and y == 4: #Blackwater Bay 2
        print("Looking around the village, you don't find much, except for a fishing\n\
spear, some money and some loose notes about a 'shark-snake'.")
        print()
        if water >= 4:
            print("The water churns and froths...")
        if water >= 2 and water < 4:
            print("The waves grow ever larger...")
        if water == 1:
            print("The white glow shines with a newfound intensity...")
        print("----------------")
        print("a: leave the village")
        if not "Spear" in inv:
            print("e: take the spear")
        if mo == 1:
            print("r: take the money")
        action = input(">>> ")
        if action == "a":
            x-=1
            print("You go back through the old village.")
        if action == "e" and not "Spear" in inv:
            inv.append("Spear")
            print("Picked up the spear.")
        if action == "r" and mo == 1:
            money+=4
            mo = 0
            print("Picked up 4g")
        water-=1

    elif x == 6 and y == 7: #Cantint Castille Gates
        if boss2 == 1:
            print("Emerging out of the treeline, the solid iron fortress of Cantint\n\
Castille looms above you. The door appears to be wide open, however\n\
there seems to be someone gurading it. If you want to enter, you'll\n\
most likely have to fight them.")
        else:
            print("Entering Cantint Castille, you notice a small shrine to the side\n\
of a long hallway into the keep.")
        if hp > 0:
            print("----------------")
            print("s: leave the castle")
            if boss2 == 1:
                print("e: fight the guard")
            else:
                print("w: enter the castle")
                print("e: pray at the shrine")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You decide to go back.")
            if boss2 == 1:
                if action == "e":
                    print("As you approach the guard, she unsheathes a curved scimitar\n\
and charges directly at you.")
                    bossfight(3, hp)
            else:
                if action == "e":
                    print("Praying to the shrine, you feel an innate safety around you.")
                    print("(Health recovered and checkpoint set)")
                    hp = maxhp
                    checkpoint = 1
                if action == "w":
                    print("You enter the castle.")
                    y+=1
                
    elif x == 6 and y == 8: #Cantint Castille Hallway
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(4, 7, hp)
        if hp > 0:
           print("The long hallway seems to lead to the Throne Room, very far down.\n\
While walking down, however, you find apon doors to the left and right of you.")
           print("----------------")
           print("w: head to the throne room")
           print("a: check out the left room")
           print("d: check out the right room")
           print("s: go to back to the gates")
           action = input(">>> ")
           if action == "a":
               x-=1
               print("You enter the room on your left.")
           if action == "d":
               x+=1
               print("You enter the room on your right.")
           if action == "w":
               y+=1
               print("You steel yourself, and proceed to the throne room.")
           if action == "s":
               y-=1
               print("You decide to head back to the entrance.")
           

    elif x == 5 and y == 8: #Cantint Castille Shop
        if hp > 0:
           print("Entering the room, you notice as something moves towards you. \n\
'Hey', the pile on the floor says to you. 'I'm hiding from the undead\n\
under these bedsheets. If you want, I've got some things for sale under\n\
here, if you need to stock up. I've got:\n\
1. HP Potion (heals 15HP), for 5g")
        if not "Sword of the Somber Burden" in inv:
            print("2. Sword of the Somber Burden (AP 11), for 20g")
        if maxhp == 20:
            print("3. Undead's Armor (sets maximum HP to 30), for 20g")
        print("----------------")
        print("w: enter northern room")
        print("d: return to hallway")
        print("1: purchase an HP potion")
        if not "Sword of the Somber Burden" in inv:
            print("2: purchase sword")
        if maxhp == 20:
            print("3: purchase a set of Cantint armor")
        action = input(">>> ")
        if action == "1": #HP Potion (buy)
            if money >= 5:
                money-=5
                print("'Here 'ya go.'")
                inv.append("HP Potion")
                potions.append("x")
            else:
                print("'Sorry, but you don't have the money for that.'")
        elif action == "2": #Sword (buy)
            if not "Sword of the Somber Burden" in inv:
                if money >= 20:
                    money-=20
                    print("'Here you go.'")
                    inv.append("Sword of the Somber Burden")
                    print("'Be careful with it, it's very sharp.'") 
                else:
                    print("'Sorry, but you don't have the money for that.'")
        elif action == "3": #Armor (buy)
            if maxhp == 20:
                if money >= 20:
                    money-=20
                    print("'Here 'ya go.'")
                    maxhp = 30
                    print("'This'll help you survive.'") 
                else:
                    print("'Sorry, but you don't have the money for that.'")
        elif action == "d":
            x+=1
            print("'Good luck.', the man wishes you.")
        elif action == "w":
            y+=1
            print("'Stay safe.', the man wishes you.")

        
    elif x == 5 and y == 9: #Cantint Castille Chest Room
        if hp > 0:
            print("The enter a strange, dark room. The ground is covered with\n\
skeletons, picked clean. In the center of the room is an ornate chest.")
            print("----------------")
            print("s: turn back")
            print("e: open the chest")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You decide the leave.")
            if action == "e":
                print("When you open the chest, a massive claw sprouts out of it,\n\
pulling you into it, and swallowing you whole.")
                if checkpoint == 1:
                    x = 6
                    y = 7
                    print("You enter the room on your right.")
                elif checkpoint == 0:
                    x = 5
                    y = 1
                elif checkpoint == 2:
                    x = 5
                    y = 16
                hp = 0
                print("You've died...")
                time.sleep(1)
                print("Sliding down the endless spiral...")
                time.sleep(1)
                print("Into the abyss...")
                time.sleep(1)
                print(".....")
                time.sleep(1)
                print("But enough of this.")
                time.sleep(1)
                print("Awaken now, where you began...")

    elif x == 7 and y == 8: #Cantint Castille Right Room
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(4, 7, hp)
        if hp > 0:
           print("This empty room seems normal, but who knows...")
           print("----------------")
           print("w: check out the north room")
           print("a: go back to the  hallway")
           action = input(">>> ")
           if action == "a":
               x-=1
               print("You return to the hallway.")
           if action == "w":
               y+=1
               print("You check out the northern room.")

    elif x == 7 and y == 9: #Cantint Castille Key Room
        rand = random.randint(1, 100)
        if rand >= 40:
            battle(4, 7, hp)
        if hp > 0:
            if key == 0:
                print("This room is not only a dead end, but it's also completely empty.\n\
You're about to leave, but you notice there is actually a key on the floor.")
            else:
                print("This room is not only a dead end, but it's also completely empty")
            print("----------------")
            print("s: go back")
            if key == 0:
                print("e: take the key")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You decide to go back.")
            if action == "e" and key == 0:
                print("You pick up the key")
                key = 1
                inv.append("Ornate Key")

    elif x == 6 and y == 9: #Cantint Castille Throne Room
        rand = random.randint(1, 100)
        if rand >= 40:
            battle(4, 7, hp)
        if hp > 0:
            if key == 0:
                print("You enter the ornate throne room, filled with many golden decorations.\n\
What's strange is that the Castille's Lord appears to be gone.\n\
After searching, you find nothing, except what appears to be a\n\
keyhole in the throne.")
            else:
                print("You enter the ornate throne room, filled with many golden decorations.\n\
What's strange is that the Castille's Lord appears to be gone.\n\
After searching, you find nothing, except what appears to be a\n\
keyhole in the throne. After inserting the Ornate Key you found\n\
and giving it a turn, the throne slides off of a trapdoor, leading\n\
down to who knows where.")
            print("----------------")
            print("s: leave the throne room")
            if key == 1:
                print("w: enter the trapdoor")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You return to the hallway.")
            if action == "w" and key == 1:
                y+=1
                print("You climb down the trapdoor.")

    elif x == 6 and y == 10: #Cantint Castille Secret Room
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(4, 7, hp)
        if hp > 0:
            if boss3 == 0:
                print("You are in a long hallway, lit by torches.")
            else:
                print("You are in a long hallway, lit by torches. After a bit of walking, you\n\
see a figure, shrouded in the red-golden robes of Cantint royalty, facing a\n\
plain black door. He doesn't move at all, giving off no signs of life whatsoever.")
            print("----------------")
            print("w: proceed")
            print("s: climb back up to the throne room")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You return to the throne room.")
            if action == "w":
                y+=1
                print("You check out the northern room.")

    elif x == 6 and y == 11: #Lord Arthan the Undead
        if boss3 == 1:
            print("Approaching him, the man does nothing. Then, as you are about to open the\n\
black door, you hear a slight creaking noise. Turning around, you see his\n\
skeletal face, staring straight at you, a faint white light in one of his\n\
eyes. The king of Cantint Castille draws out a golden staff.")
            bossfight(4, hp)
        else:
            print("You are facing a black door. You could swear that a slight humming sound\n\
comes from inside the door itself.")
        if hp > 0:
            print("----------------")
            print("w: open the door")
            print("s: turn back")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You decide to go back.")
            if action == "w":
                y+=1
                print("Pushing open the black door, you enter the doorway, walking down the steep\n\
spiral staircase that lies beyond it.")

    elif x == 6 and y == 12: #The Black Chasm of Undead
        rand = random.randint(1, 100)
        if rand >= 50:
            battle(5, 9, hp)
        if hp > 0:
           print("You emerge onto a large, natural underground bridge, overlooking a large cave,\n\
with large stalagmites poking up out of the ground. Looking ahead, you see the\n\
path leads into a smaller cave in the side of the chasm's wall.")
           print("----------------")
           print("w: continue into the cave")
           print("s: return through the black door")
           action = input(">>> ")
           if action == "s":
               y-=1
               print("You return to Cantint Castille.")
           if action == "w":
               y+=1
               print("You enter the cave.")

    elif x == 6 and y == 13: #The Black Chasm Crossroads
        rand = random.randint(1, 100)
        if rand >= 65:
            battle(5, 9, hp)
        if hp > 0:
            print("Entering the cave, you notice it is much larger than it appeared. However, you\n\
can't simply exit the cave, as all the paths snake around and through the cave,\n\
intertwining to the point where you don't know where each one leads to.")
            print("----------------")
            print("w: take the middle path")
            print("a: take the left path")
            print("d: take the right path")
            print("s: leave the cave")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You return to the Chasm's entrance.")
            if action == "w":
                x-=1
                print("Following the path, you eventually wind up exiting the cave, exiting onto\n\
the chasm's floor.")
            if action == "a":
                x+=1
                print("You take a path.")
            if action == "d":
                y+=1
                print("You take a path.")

    elif x == 6 and y == 14: #The Black Chasm - Treasure Room (Axe)
        rand = random.randint(1, 100)
        if rand >= 65:
            battle(5, 9, hp)
        if hp > 0:
            if not "Eos Battleaxe" in inv:
                print("Eventually the path leads into a very small stone room, with a battlaxe hanging\n\
on the wall. It's engraved with the sigil of the Eos Kingdom.")
            else:
                print("Eventually the path leads into a very small, empty stone room.")
            print("----------------")
            print("s: go back")
            if not "Eos Battleaxe" in inv:
                print("e: take the axe")
            action = input(">>> ")
            if action == "s":
                y-=1
                print("You go back to the cave's entrance.")
            if action == "e" and not "Eos Battleaxe" in inv:
                inv.append("Eos Battleaxe")
                print("Picked up the axe.")

    elif x == 7 and y == 13: #The Black Chasm - Treasure Room (Money)
        rand = random.randint(1, 100)
        if rand >= 65:
            battle(5, 9, hp)
        if hp > 0:
            if mm == 1:
                print("Eventually the path leads into a very small stone room, with a small pouch\n\
of coins, resting on the floor.")
            else:
                print("Eventually the path leads into a very small, empty stone room.")
            print("----------------")
            print("s: go back")
            if mm == 1:
                print("e: take the money")
            action = input(">>> ")
            if action == "s":
                x-=1
                print("You go back to the cave's entrance.")
            if action == "e" and mm == 1:
                money+=5
                mm = 0
                print("Picked up 5g.")

    elif x == 5 and y == 13: #The Black Chasm Floor
        rand = random.randint(1, 100)
        if rand >= 65:
            battle(5, 9, hp)
        if hp > 0:
            print("Peering through the stalagmites, you notice a small crack in the chasm wall.")
            print("----------------")
            print("w: enter the crack in the wall")
            print("d: go back into the cave")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You crawl through the crack in the chasm wall. Eventually, you emerge\n\
into another section of the chasm.")
            if action == "d":
                x+=1
                print("You enter the cave.")

    elif x == 5 and y == 14: #The Black Chasm Floor 2
        rand = random.randint(1, 100)
        if rand >= 50:
            battle(5, 9, hp)
        if hp > 0:
            print("You find yourself on the chasm floor.")
            print("----------------")
            print("w: progress through the cavern")
            print("s: enter the crack in the wall")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You progress through the chasm.")
            if action == "s":
                y-=1
                print("You enter the small crack.")

    elif x == 5 and y == 15: #The Black Chasm Floor 3
        rand = random.randint(1, 100)
        if rand >= 50:
            battle(5, 9, hp)
        if hp > 0:
            print("You find yourself on the chasm floor.")
            print("----------------")
            print("w: progress through the cavern")
            print("s: go back")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You progress through the chasm.\n\
Going around a bend, you suddenly find yourself in front of the Eos Kingdom's\n\
castle, strangely at the bottom of the chasm.")
            if action == "s":
                y-=1
                print("You go back through the chasm.")

    elif x == 5 and y == 16: #Eos Kingdom Entrance
        rand = random.randint(1, 100)
        if hp > 0:
            print("You find yourself in front of the ancient Eos Kingdom's gate. On the\n\
opposite side, you see a small path leading downwards and a small shrine, with\n\
a prietess praying at it. Despite her undead appearance, she seems to be quite\n\
sane, and offers to sell you some items.")
            print("----------------")
            print("d: enter the Eos castle")
            print("s: go back into the Black Chasm")
            print("w: follow the small path")
            print("e: pray at the shrine")
            print("1: purchase an HP Potion (restore 15HP), for 5g")
            if key1 == 0:
                print("2: purchase a red gem, for 20g")
            if not maxhp == 40:
                print("3: purchase a set of Eos armor (sets maximum HP to 40), for 30g")
            if not "Life Patch" in inv:
                print("4. Life Patch (increases HP Potion potency), for 16g")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You decide to follow the small path.")
            if action == "s":
                y-=1
                print("You return the Black Chasm.")
            if action == "d":
                x+=1
                print("Steeling yourself, you enter the Eos Kingdom")
            if action == "e":
                print("Praying to the shrine, you feel a brief moment of rest.")
                print("(Health recovered and checkpoint set)")
                hp = maxhp
                checkpoint = 2
            if action == "1":
                if money >= 5:
                    print("'May thee stay safe.'")
                    money-=5
                    inv.append("HP Potion")
                    potions.append("x")
                else:
                    print("'I appologise, but thee dosn't haveth enough money.'")
            if action == "2" and key1 == 0:
                if money >= 6:
                    print("'I pray this helpeth thee on thine journey.'")
                    inv.append("Red Gem")
                    key1 = 1
                    keys+=1
                    money-=20
                else:
                    print("'I appologise, but thee dosn't haveth enough money.'")
            if action == "3" and not maxhp == 40:
                if money >= 30:
                    print("'I hope this shall assist thee, during thine quest.'")
                    maxhp = 40
                    money-=30
                else:
                    print("'I appologise, but thee dosn't haveth enough money.'")
            if action == "4" and not "Life Patch" in inv:
                if money >= 16:
                    print("'I pray for this to assist thee.'")
                    inv.append("Life Patch")
                    money-=16
                else:
                    print("'I appologise, but thee dosn't haveth enough money.'")

    elif x == 5 and y == 17: #Cavern Entrance
        rand = random.randint(1, 100)
        if rand >= 80:
            battle(5, 9, hp)
        if hp > 0:
            print("Progressing along the path, you eventually come across a cave,\n\
pitch black, except for a shaft of light coming from the sky, very\n\
very far in.")
            print("----------------")
            print("a: enter the cavern")
            print("s: go back")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You enter the cave.")
            if action == "s":
                y-=1
                print("You decide to go back.")


    elif x == 4 and y == 17: #Cavern Boss
        if hp > 0:
            if boss4 == 1:
                print("Something feels... off...")
                bossfight(5, hp)
            else:
                print("You walk through the pitch-black cave.")
            print("----------------")
            print("a: go to the light shaft")
            print("d: go back")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You enter the cave.")
            if action == "d":
                x+=1
                print("You decide to go back.")

    elif x == 3 and y == 17: #Cavern: THE SWORD! FINALLY!!!
        if hp > 0:
            if boss1 == 1:
                print("Looking around the shaft of light, you unfortunately find nothing.")
                bossfight(5, hp)
            else:
                if not "Sword of the Solemn Pain" in inv:
                    print("Approaching the shaft of light, you see the sword of He of the Solemn\n\
Pain, embedded in the floor, in the center of the skylight.")
                else:
                    print("Looking around the shaft of light, you unfortunately find nothing.")
            print("----------------")
            if boss1 == 0 and not "Sword of the Solemn Pain" in inv:
                print("e: take the sword")
            print("d: go back")
            action = input(">>> ")
            if action == "e":
                print("Pulling the Sword of the Solemn Pain out of the floor, you notice\n\
that, despite the fall, it is still in perfect condition.\n\
You finally claim your well-earned prize.")
                inv.append("Sword of the Solemn Pain")
            if action == "d":
                x+=1
                print("You decide to go back.")

    elif x == 6 and y == 16: #Eos Courtyard
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(10, 14, hp)
        if hp > 0:
            print("You find yourself in the Eos courtyard. The statues of many past kings\n\
lie broken on the ground. Looking into the broken windows, you see mobs of\n\
undead roaming through the halls, along with things better left undescribed.")
            print("----------------")
            print("a: go to the shrine")
            print("d: enter the keep")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You leave the courtyard.")
            if action == "d":
                x+=1
                print("You enter the castle.")

    elif x == 7 and y == 16: #Eos Castle
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(10, 14, hp)
        if hp > 0:
            print("Looking around you, you see two staircases leading up and down, respectively.\n\
The walls are lined with torches, glowing with a strange blue light.")
            print("----------------")
            print("w: take the ascending staircase")
            print("d: take the descending staircase")
            print("a: return to the courtyard")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You go back to the courtyard.")
            if action == "d":
                x+=1
                print("You take the descending staircase.")
            if action == "w":
                y+=1
                print("You take the ascending staircase.")

    elif x == 8 and y == 16: #Eos Library
        if hp > 0:
            print("You enter what was once a massive library, but it was burnt to the ground.\n\
Shifting through the piles of ashes, you find a few scraps of parchment that\n\
are still legible.")
            print("----------------")
            print("a: leave the ruined library")
            print("1: read the old note")
            print("2: read the torn note")
            print("3: read the long note")
            print("4: read the hastily written note")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You leave the burnt library.")
            if action == "1":
                print("The note reads:")
                print("Cantint have beaten us, there is nothing else for it. I can hear the\n\
explosions rocking the castle. If we are lucky, the support beams will\n\
hold, and we won't fall into the great dark below. Who thought this was a\n\
good place to build a castle?")
            if action == "2":
                print("The note reads:")
                print("Most of the army is dead, killed by the creatures lurking in this forsaken\n\
chasm. The queen has ordered my sorcerers and I to research a way to fix this,\n\
but some forms of magic should not be used lightly. Perhap")
            if action == "3":
                print("The note reads:")
                print("The sorcerers have done a good job. With their use of necromancy, we\n\
have been able to wrest control over the chasm. Perhaps one day we will\n\
even be able to take revenge over the ones who sent us into this abyss.\n\
My only fear is that the sorcerers seem to be anxious about something.\n\
Perhaps it has to do with that one undead soldier going mad? Whatever\n\
it is, I'm confident our necromancers can handle it.")
            if action == "4":
                print("The note reads:")
                print("I don't know how much time I have left. They have taken the castle,\n\
probably Cantint as well. The Brotherhood of the Solemn Burden have\n\
failed. They two of the Silent Pain have gone missing. There is nobody\n\
left who can stop thi__\n\
                       \\")
                if key2 == 0:
                    print("Resting on the parchment is a pristine blue gem, which you\n\
decide to take.")
                    key2 = 1
                    keys+=1
                    inv.append("Blue Gem")

    elif x == 7 and y == 17: #Eos Hallways
        rand = random.randint(1, 100)
        if rand >= 60:
            battle(10, 14, hp)
        if hp > 0:
            print("You enter a long hallway. A hole has been blown into the wall, giving\n\
you a view of the courtyard. Further down, you can hear the faint\n\
sounds of monsters.")
            print("----------------")
            print("w: head down the hall")
            print("s: head back to the entrance")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You go down the hall.")
            if action == "s":
                y-=1
                print("You return to the entrance.")

    elif x == 7 and y == 18: #Door of the Dead
        rand = random.randint(1, 100)
        if rand >= 70:
            battle(10, 14, hp)
        if hp > 0:
            if keys < 4:
                print("You eventually come to a door with 5 holes in it. There doesn't appear\n\
to be any way to open it. To the left there is another, smaller door,\n\
and to the right there is a ladder going up.")
            else:
                print("You eventually come to a door with 5 holes in it. Your old pendant and\n\
gems seem to be shaking. To the left there is another, smaller door,\n\
and to the right there is a ladder going up.")
            print("----------------")
            if keys >= 4:
                print("w: approach the door")
            print("a: enter the smaller door")
            print("d: head up the ladder")
            print("s: return to the hallway")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You go back to the courtyard.")
            if action == "d":
                x+=1
                print("You take the descending staircase.")
            if action == "w":
                if keys >= 4:
                    y+=1
                    print("Approaching the door, your pendant and gems fly out of your pocket,\n\
inserting themselves into the door. Walking into it, you go right\n\
through the wall. Your items return to your pocket.")
            if action == "s":
                y-=1
                print("You decide to go back.")

    elif x == 6 and y == 18: #Code Room
        if hp > 0:
            if key3 == 0:
                print("You enter a small room, with the words '20 by 5' written hastily on\n\
the wall. Looking down, you notice a dial with the numbers 0 to 10 on\n\
it. Above you there a metallic trapdoor, from which strange noises can\n\
be heard.")
            else:
                print("You enter a small room, with the words '20 by 5' written hastily on\n\
the wall. Looking down, you notice a dial with the numbers 0 to 10 on\n\
it. Above you there a metallic trapdoor, from which strange noises can\n\
be heard. The compartment on the floor is now empty.")
            print("----------------")
            if key3 == 0:
                print("e: turn the dial")
            print("d: head up the ladder")
            action = input(">>> ")
            if action == "e":
                print("Inspecting the dial, you see it has numbers from 0-10 on it.")
                print("What will you turn it to?")
                action = input(">>> ")
                if action == "4":
                    print("Suddenly, a very hidden compartment in the floor opens up, revealing\n\
a sparkling yellow gem.")
                    inv.append("Yellow Gem")
                    key3 = 1
                    keys+=1
                else:
                    print("Suddenly, the trapdoor above you opens up, dropping something\n\
on top of you!")
                    battle(10, 14, hp)
            if action == "d":
                x+=1
                print("You head back into the main chamber.")

    elif x == 8 and y == 18: #The Great Belfry
        if hp > 0:
            if key4 == 0:
                print("You climb up into a large belfry, but you don't seem to be alone.")
                battle(10, 14, hp)
                if hp > 0:
                    print("While you did win the fight, you don't seem to be finished just yet.")
                    battle(10, 14, hp)
                    if hp > 0:
                        print("Checking around, you find nothing but a small green gem, which you take.")
                        inv.append("Green Gem")
                        key4 = 1
                        keys+=1
            else:
                print("You climb up into a large belfry, but there doesn't seem to be anything of\n\
interest.")
            print("----------------")
            print("a: head down the ladder")
            action = input(">>> ")
            if action == "a":
                x-=1
                print("You head back down into the main chamber.")

    elif x == 7 and y == 19: #Royal Sorcerer Navaler
        if boss5 == 1:
            print("You find yourself in a long stone hall. Chanting undead bear torhces,\n\
looking at you intently. An undead sorceror steps out from the croud...")
            bossfight(6, hp)
            if boss5 == 0:
                print("The undead scatter, the torches going out instantly.")
                print("Suddenly, you hear a woman's voice.")
                print("'Brave one, you have borne your Solemn Pain for a long time...\n\
Come, end this madness, and redeem us...'")
        else:
            print("You're in a long, dark hall.")
        if hp > 0:
            print("----------------")
            print("w: go forward")
            print("s: turn back")
            action = input(">>> ")
            if action == "w":
                y+=1
                print("You proceed down the hall")
            if action == "s":
                y-=1
                print("You decide to go back.")

    elif x == 7 and y == 20: #Themis, Undead Queen
        print("You're walking down the dark hall, when  the torch-bearing undead suddenly\n\
appear, illuminating the room. You're standing in front of a stone throne,\n\
surrounded by skulls. On the throne sits a skeletal queen. In a chilling voice\n\
she says: 'Bring this madness to an end... For it is thine fate...' The queen\n\
stands up and whips a scythe of bones out of seemingly nowhere.")
        print()
        print("You accept your fate.")
        print()
        bossfight(7, hp)
        if boss6 == 0:
            break






    if (x == 8 or x == 9) and y == 4 and water == 0: #Serpent-Shark Trigger
        print()
        print("But now you have dwindled too long... Out of the shining spot in\n\
the water, a massive Serpent-Shark climbs out...")
        bossfight(2, hp, 60)
        



    if action == "i": #INVENTORY
        print("Which item will you use?")
        if "HP Potion" in inv:
            if "Life Patch" in inv:
                print("1.HP Potion - heal 20HP")
            else:
                print("1.HP Potion - heal 15HP")
        if "Atlas" in inv:
            print("2.Atlas - see various intersting locations")
        if "Longsword" in inv and not weapon == 1:
            print("W1.Longsword - AP 5")
        if "Spear" in inv and not weapon == 2:
            print("W2.Spear - AP 6")
        if "Bronze Scimitar" in inv and not weapon == 3:
            print("W3.Bronze Scimitar - AP 9")
        if "Sword of the Somber Burden" in inv and not weapon == 4:
            print("W4.Sword of the Somber Burden - AP 11")
        if "Eos Battleaxe" in inv and not weapon == 5:
            print("W5.Eos Battleaxe - AP 15")
        if "Sword of the Solemn Pain" in inv and not weapon == 6:
            print("W6.Sword of the Solemn Pain - AP 20")
        print("i: nothing")
        action = input(">>> ")
        if action == "1" and "HP Potion" in inv:
            if "Life Patch" in inv:
                hp+=20
                print("Healed 20HP")
            else:
                hp+=15
                print("Healed 15HP")
            inv.remove("HP Potion")
            potions.remove("x")
            if hp > maxhp:
                hp = maxhp
        if action == "2" and "Atlas" in inv:
            print("x:6/y:7 - Cantint Castille, the forsaken castle of Lord Arthan")
            print("x:5/y:2 - Harelia Town, the last true bastion of civilization")
            print("x:8/y:4 - Blackwater Bay, from which none return")
            print("x:3/y:5 - The Bridge of Eos, last remnant of the great Eos Kingdom")
        if action == "W1" and "Longsowrd" in inv and not weapon == 1:
            print("Longsword equipped")
            weapon = 1
        if action == "W2" and "Spear" in inv and not weapon == 2:
            print("Spear equipped")
            weapon = 2
        if action == "W3" and "Bronze Scimitar" in inv and not weapon == 3:
            print("Scimitar equipped")
            weapon = 3
        if action == "W4" and "Sword of the Somber Burden" in inv and not weapon == 4:
            print("Sword of the Somber Burden equipped")
            weapon = 4
        if action == "W5" and "Eos Battleaxe" in inv and not weapon == 5:
            print("Eos Battleaxe equipped")
            weapon = 5
        if action == "W6" and "Sword of the Solemn Pain" in inv and not weapon == 6:
            print("Sword of the Solemn Pain equipped")
            weapon = 6

    if action == "save":
        print("Saved")
        with open('savefile.dat', 'wb') as f:
            pickle.dump([hp, x, y, money, maxhp, weapon, inv, potions, boss1, boss2, boss3, boss4, boss5, boss6, mo, mm, key, key1, key2, key3, key4, keys, checkpoint], f, protocol=2)

    if action == "load":
        print("Loaded")
        with open('savefile.dat', 'rb') as f:
            hp, x, y, money, maxhp, weapon, inv, potions, boss1, boss2, boss3, boss4, boss5, boss6, mo, mm, key, key1, key2, key3, key4, keys, checkpoint = pickle.load(f)

    if hp < 1:
        if x == 5 and y == 1:
            hp = maxhp
        if x == 6 and y == 7:
            hp = maxhp
        if x == 5 and y == 16:
            hp = maxhp
    input()

time.sleep(6)
print("\n\
\n\
\n\
\n\
")
print("                      DEAD AGAIN")
print("               A game by Tridad Studios")
